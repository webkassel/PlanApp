/* allicaneat.food — Steuerungs-Dashboard: Inhalt + Rechenhilfen.
   Struktur/Inhalt getrennt: dieses File wird später 1:1 durch JSON ersetzt.
   Aufgaben sind bewusst leer — Demo-Bestand liegt in daten-demo.js. */
window.AICE_DATA = {
  heute: "2026-08-28",
  prioritaeten: [
    { key: "dringend", label: "Dringend", rang: 1 },
    { key: "hoch",     label: "Hoch",     rang: 2 },
    { key: "normal",   label: "Normal",   rang: 3 },
    { key: "niedrig",  label: "Niedrig",  rang: 4 }
  ],
  restaurants: [
    { id: "allgemein", name: "Allgemein", allgemein: true, status: "Laufend", ort: "—",
      kontakt: null, notiz: "Aufgaben ohne Restaurantbezug — Pilotphase, Prozesse, Material.",
      dateien: [], aufgaben: [] },
    { id: "sorabowls", name: "Sora Bowls", status: "Neu angelegt",
      kueche: "Bowls", ort: "Kassel",
      kontakt: null, notiz: "",
      dateien: [], aufgaben: [] }
  ]
};

window.AICE_UTIL = (function () {
  var WT = ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"];
  var PRIO = {
    dringend: { label: "Dringend", rang: 1, code: "D", marken: "!!!", punkte: 4 },
    hoch:     { label: "Hoch",     rang: 2, code: "H", marken: "!!",  punkte: 3 },
    normal:   { label: "Normal",   rang: 3, code: "N", marken: "!",   punkte: 2 },
    niedrig:  { label: "Niedrig",  rang: 4, code: "L", marken: "·",   punkte: 1 }
  };
  function tag(s) { var p = s.split("-"); return new Date(+p[0], +p[1] - 1, +p[2]); }
  function diff(a, b) { return Math.round((tag(b) - tag(a)) / 86400000); }
  function fmt(s) { var d = tag(s); return ("0" + d.getDate()).slice(-2) + "." + ("0" + (d.getMonth() + 1)).slice(-2) + "."; }
  function fmtLang(s) { var d = tag(s); return WT[d.getDay()] + " " + fmt(s) + tag(s).getFullYear().toString().slice(-2); }
  function relativ(heute, faellig) {
    var t = diff(heute, faellig);
    if (t < 0) return { tage: t, ueberfaellig: true, text: "überfällig seit " + Math.abs(t) + (Math.abs(t) === 1 ? " Tag" : " Tagen"), kurz: Math.abs(t) + "T über" };
    if (t === 0) return { tage: 0, ueberfaellig: false, text: "heute fällig", kurz: "heute" };
    if (t === 1) return { tage: 1, ueberfaellig: false, text: "morgen fällig", kurz: "morgen" };
    return { tage: t, ueberfaellig: false, text: "in " + t + " Tagen", kurz: "in " + t + " T" };
  }
  return { PRIO: PRIO, prio: function (k) { return PRIO[k] || PRIO.normal; }, diff: diff, fmt: fmt, fmtLang: fmtLang, relativ: relativ, tag: tag };
})();
