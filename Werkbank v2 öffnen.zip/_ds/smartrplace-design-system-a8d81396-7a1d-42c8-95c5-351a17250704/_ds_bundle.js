/* @ds-bundle: {"format":3,"namespace":"SmartrplaceDesignSystem_a8d813","components":[{"name":"Avatar","sourcePath":"components/core/Avatar.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Divider","sourcePath":"components/core/Divider.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"Metric","sourcePath":"components/data/Metric.jsx"},{"name":"ProgressBar","sourcePath":"components/data/ProgressBar.jsx"},{"name":"Alert","sourcePath":"components/feedback/Alert.jsx"},{"name":"Dialog","sourcePath":"components/feedback/Dialog.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Button","sourcePath":"components/forms/Button.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"IconButton","sourcePath":"components/forms/IconButton.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Textarea","sourcePath":"components/forms/Textarea.jsx"},{"name":"Breadcrumb","sourcePath":"components/navigation/Breadcrumb.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"}],"sourceHashes":{"components/core/Avatar.jsx":"845db283906f","components/core/Badge.jsx":"7c33c9f30da6","components/core/Card.jsx":"0f504146db58","components/core/Divider.jsx":"08fb60e584f2","components/core/Tag.jsx":"cf8475affa1e","components/data/Metric.jsx":"21a6ff5bf569","components/data/ProgressBar.jsx":"87d355966484","components/feedback/Alert.jsx":"349eb161a577","components/feedback/Dialog.jsx":"022e2efbb647","components/feedback/Toast.jsx":"0a5841c39a5d","components/feedback/Tooltip.jsx":"b494e6fdb2c3","components/forms/Button.jsx":"bdb95c10b489","components/forms/Checkbox.jsx":"7640ac446713","components/forms/IconButton.jsx":"498542d6ee97","components/forms/Input.jsx":"207225be5ffa","components/forms/Radio.jsx":"a3f371f366d5","components/forms/Select.jsx":"9b76a2b6cadb","components/forms/Switch.jsx":"0b0878faacac","components/forms/Textarea.jsx":"68ae8bf5acca","components/navigation/Breadcrumb.jsx":"f99364db7892","components/navigation/Tabs.jsx":"38d9f13fe422","ui_kits/dashboard/Overview.jsx":"034bed5d1f5f","ui_kits/dashboard/Screens.jsx":"396732d1892b","ui_kits/dashboard/Shell.jsx":"91e0fb2f4073","ui_kits/website/Chrome.jsx":"eafdea7a2677","ui_kits/website/Home.jsx":"908bb000929e","ui_kits/website/Pages.jsx":"26f89ebc8f18"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.SmartrplaceDesignSystem_a8d813 = window.SmartrplaceDesignSystem_a8d813 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Avatar with image or initials fallback. */
function Avatar({
  src,
  name = "",
  size = 40,
  style = {},
  ...rest
}) {
  const initials = name.split(" ").map(w => w[0]).filter(Boolean).slice(0, 2).join("").toUpperCase();
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      width: size,
      height: size,
      borderRadius: "50%",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      overflow: "hidden",
      background: "var(--sr-green-100)",
      color: "var(--sr-tannengruen)",
      fontFamily: "var(--font-sans)",
      fontWeight: 600,
      fontSize: size * 0.38,
      letterSpacing: "0.02em",
      flexShrink: 0,
      ...style
    }
  }, rest), src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name,
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover"
    }
  }) : initials || "•");
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Small status label. Soft tinted backgrounds by tone. */
function Badge({
  children,
  tone = "neutral",
  solid = false,
  style = {},
  ...rest
}) {
  const soft = {
    neutral: {
      bg: "var(--sr-neutral-100)",
      fg: "var(--sr-neutral-700)"
    },
    brand: {
      bg: "var(--sr-green-100)",
      fg: "var(--sr-tannengruen)"
    },
    neon: {
      bg: "var(--sr-neongruen)",
      fg: "var(--sr-dunkelgruen)"
    },
    success: {
      bg: "#DDEFE7",
      fg: "#1E6B52"
    },
    warning: {
      bg: "#F6EBD3",
      fg: "#8A5F0F"
    },
    danger: {
      bg: "#F4DEDC",
      fg: "#8E2F28"
    },
    info: {
      bg: "#DCEAF1",
      fg: "#255A75"
    }
  };
  const solids = {
    neutral: {
      bg: "var(--sr-neutral-700)",
      fg: "#fff"
    },
    brand: {
      bg: "var(--sr-tannengruen)",
      fg: "#fff"
    },
    neon: {
      bg: "var(--sr-neongruen)",
      fg: "var(--sr-dunkelgruen)"
    },
    success: {
      bg: "var(--sr-success)",
      fg: "#fff"
    },
    warning: {
      bg: "var(--sr-warning)",
      fg: "#fff"
    },
    danger: {
      bg: "var(--sr-danger)",
      fg: "#fff"
    },
    info: {
      bg: "var(--sr-info)",
      fg: "#fff"
    }
  };
  const c = (solid ? solids : soft)[tone];
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "6px",
      height: "22px",
      padding: "0 10px",
      borderRadius: "var(--radius-pill)",
      background: c.bg,
      color: c.fg,
      fontFamily: "var(--font-sans)",
      fontSize: "12px",
      fontWeight: 600,
      letterSpacing: "0.02em",
      whiteSpace: "nowrap",
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Surface container. `elevated` for floating cards, `outlined` for flat,
 * `brand` for the deep-green feature card.
 */
function Card({
  children,
  variant = "elevated",
  padding = "24px",
  as = "div",
  style = {},
  ...rest
}) {
  const variants = {
    elevated: {
      background: "var(--surface-card)",
      border: "1px solid var(--border-subtle)",
      boxShadow: "var(--shadow-md)"
    },
    outlined: {
      background: "var(--surface-card)",
      border: "1px solid var(--border-default)",
      boxShadow: "none"
    },
    sunken: {
      background: "var(--surface-sunken)",
      border: "1px solid var(--border-subtle)",
      boxShadow: "none"
    },
    brand: {
      background: "var(--surface-brand)",
      border: "1px solid transparent",
      color: "var(--text-on-dark)",
      boxShadow: "var(--shadow-lg)"
    }
  };
  const Tag = as;
  return /*#__PURE__*/React.createElement(Tag, _extends({
    style: {
      borderRadius: "var(--radius-lg)",
      padding,
      ...variants[variant],
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Divider.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Divider line, horizontal or vertical, with optional centered label. */
function Divider({
  orientation = "horizontal",
  label,
  style = {},
  ...rest
}) {
  if (orientation === "vertical") {
    return /*#__PURE__*/React.createElement("span", _extends({
      role: "separator",
      "aria-orientation": "vertical",
      style: {
        width: "1px",
        alignSelf: "stretch",
        background: "var(--border-subtle)",
        ...style
      }
    }, rest));
  }
  if (label) {
    return /*#__PURE__*/React.createElement("div", _extends({
      role: "separator",
      style: {
        display: "flex",
        alignItems: "center",
        gap: "12px",
        ...style
      }
    }, rest), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        height: 1,
        background: "var(--border-subtle)"
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "var(--font-sans)",
        fontSize: "12px",
        textTransform: "uppercase",
        letterSpacing: "0.1em",
        color: "var(--text-subtle)"
      }
    }, label), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        height: 1,
        background: "var(--border-subtle)"
      }
    }));
  }
  return /*#__PURE__*/React.createElement("hr", _extends({
    style: {
      border: "none",
      height: 1,
      background: "var(--border-subtle)",
      margin: 0,
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Divider });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Divider.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Removable/selectable tag chip. */
function Tag({
  children,
  onRemove,
  selected = false,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "8px",
      height: "30px",
      padding: onRemove ? "0 8px 0 12px" : "0 14px",
      borderRadius: "var(--radius-pill)",
      background: selected ? "var(--sr-green-100)" : "var(--surface-card)",
      border: `1.5px solid ${selected ? "var(--brand)" : "var(--border-default)"}`,
      color: selected ? "var(--text-brand)" : "var(--text-body)",
      fontFamily: "var(--font-sans)",
      fontSize: "13.5px",
      fontWeight: 500,
      ...style
    }
  }, rest), children, onRemove && /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Remove",
    onClick: onRemove,
    style: {
      width: 18,
      height: 18,
      display: "grid",
      placeContent: "center",
      border: "none",
      borderRadius: "50%",
      background: "transparent",
      color: "var(--text-muted)",
      cursor: "pointer",
      fontSize: 13,
      lineHeight: 1
    }
  }, "\u2715"));
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/data/Metric.jsx
try { (() => {
/**
 * KPI metric block — the core data display for energy dashboards.
 * Mono value, uppercase display overline label, optional delta.
 */
function Metric({
  label,
  value,
  unit,
  delta,
  deltaTone,
  hint,
  style = {}
}) {
  const tone = deltaTone || (typeof delta === "string" && delta.trim().startsWith("-") ? "positive" : "neutral");
  const deltaColor = {
    positive: "var(--sr-success)",
    negative: "var(--sr-danger)",
    neutral: "var(--text-muted)"
  }[tone];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      textTransform: "uppercase",
      letterSpacing: "0.18em",
      fontSize: "11.5px",
      color: "var(--text-brand)",
      marginBottom: "8px"
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      gap: "6px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "34px",
      fontWeight: 500,
      color: "var(--text-strong)",
      letterSpacing: "-0.01em",
      lineHeight: 1
    }
  }, value), unit && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "15px",
      color: "var(--text-muted)"
    }
  }, unit)), (delta || hint) && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "8px",
      marginTop: "8px"
    }
  }, delta && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "13px",
      fontWeight: 500,
      color: deltaColor
    }
  }, delta), hint && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "12.5px",
      color: "var(--text-subtle)"
    }
  }, hint)));
}
Object.assign(__ds_scope, { Metric });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Metric.jsx", error: String((e && e.message) || e) }); }

// components/data/ProgressBar.jsx
try { (() => {
/** Horizontal progress / usage bar. `value` 0–100. */
function ProgressBar({
  value = 0,
  max = 100,
  tone = "brand",
  label,
  showValue = false,
  height = 8,
  style = {}
}) {
  const pct = Math.max(0, Math.min(100, value / max * 100));
  const fill = {
    brand: "var(--brand)",
    neon: "var(--sr-neongruen)",
    success: "var(--sr-success)",
    warning: "var(--sr-warning)",
    danger: "var(--sr-danger)"
  }[tone];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      ...style
    }
  }, (label || showValue) && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      marginBottom: 6,
      fontSize: "13px",
      color: "var(--text-body)"
    }
  }, label && /*#__PURE__*/React.createElement("span", null, label), showValue && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      color: "var(--text-muted)"
    }
  }, Math.round(pct), "%")), /*#__PURE__*/React.createElement("div", {
    role: "progressbar",
    "aria-valuenow": value,
    "aria-valuemax": max,
    style: {
      height,
      background: "var(--sr-neutral-200)",
      borderRadius: 999,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: `${pct}%`,
      height: "100%",
      background: fill,
      borderRadius: 999,
      transition: "width var(--dur-slow) var(--ease-out)"
    }
  })));
}
Object.assign(__ds_scope, { ProgressBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/ProgressBar.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Alert.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Inline message banner. */
function Alert({
  title,
  children,
  tone = "info",
  onClose,
  icon = null,
  style = {},
  ...rest
}) {
  const tones = {
    info: {
      bg: "#DCEAF1",
      border: "#B9D4E2",
      fg: "#255A75"
    },
    success: {
      bg: "#DDEFE7",
      border: "#B7DDCB",
      fg: "#1E6B52"
    },
    warning: {
      bg: "#F6EBD3",
      border: "#E7D3A6",
      fg: "#8A5F0F"
    },
    danger: {
      bg: "#F4DEDC",
      border: "#E6BFBB",
      fg: "#8E2F28"
    },
    brand: {
      bg: "var(--sr-green-50)",
      border: "var(--sr-green-200)",
      fg: "var(--sr-tannengruen)"
    }
  };
  const c = tones[tone];
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "alert",
    style: {
      display: "flex",
      gap: "12px",
      padding: "14px 16px",
      borderRadius: "var(--radius-md)",
      background: c.bg,
      border: `1px solid ${c.border}`,
      color: c.fg,
      fontFamily: "var(--font-sans)",
      ...style
    }
  }, rest), icon && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      marginTop: 1
    }
  }, icon), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, title && /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600,
      fontSize: "14.5px",
      marginBottom: children ? 3 : 0
    }
  }, title), children && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "13.5px",
      lineHeight: 1.45,
      opacity: 0.92
    }
  }, children)), onClose && /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Dismiss",
    onClick: onClose,
    style: {
      border: "none",
      background: "transparent",
      color: "inherit",
      cursor: "pointer",
      fontSize: 15,
      opacity: 0.7,
      lineHeight: 1
    }
  }, "\u2715"));
}
Object.assign(__ds_scope, { Alert });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Alert.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Dialog.jsx
try { (() => {
/** Modal dialog with overlay. Controlled via `open`. */
function Dialog({
  open,
  onClose,
  title,
  description,
  children,
  footer,
  width = 480,
  style = {}
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "fixed",
      inset: 0,
      zIndex: 100,
      display: "grid",
      placeItems: "center",
      padding: "24px",
      background: "rgba(3, 35, 27, 0.42)",
      backdropFilter: "blur(2px)"
    },
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    role: "dialog",
    "aria-modal": "true",
    onClick: e => e.stopPropagation(),
    style: {
      width: "100%",
      maxWidth: width,
      background: "var(--surface-card)",
      borderRadius: "var(--radius-lg)",
      boxShadow: "var(--shadow-xl)",
      padding: "26px",
      fontFamily: "var(--font-sans)",
      ...style
    }
  }, title && /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "24px",
      lineHeight: 1.05,
      color: "var(--text-strong)",
      margin: 0
    }
  }, title), description && /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "14.5px",
      lineHeight: 1.5,
      color: "var(--text-muted)",
      margin: "10px 0 0"
    }
  }, description), children && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 18
    }
  }, children), footer && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "flex-end",
      gap: 10,
      marginTop: 24
    }
  }, footer)));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Toast notification card. Pair with your own stacking container. */
function Toast({
  title,
  children,
  tone = "neutral",
  onClose,
  icon = null,
  style = {},
  ...rest
}) {
  const accent = {
    neutral: "var(--sr-neutral-500)",
    brand: "var(--sr-tannengruen)",
    success: "var(--sr-success)",
    warning: "var(--sr-warning)",
    danger: "var(--sr-danger)"
  }[tone];
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "status",
    style: {
      display: "flex",
      gap: "12px",
      alignItems: "flex-start",
      width: "340px",
      padding: "14px 16px",
      background: "var(--surface-card)",
      borderRadius: "var(--radius-md)",
      boxShadow: "var(--shadow-lg)",
      borderLeft: `3px solid ${accent}`,
      fontFamily: "var(--font-sans)",
      ...style
    }
  }, rest), icon && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      color: accent,
      marginTop: 1
    }
  }, icon), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, title && /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600,
      fontSize: "14.5px",
      color: "var(--text-strong)"
    }
  }, title), children && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "13.5px",
      lineHeight: 1.45,
      color: "var(--text-muted)",
      marginTop: title ? 2 : 0
    }
  }, children)), onClose && /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Dismiss",
    onClick: onClose,
    style: {
      border: "none",
      background: "transparent",
      color: "var(--text-subtle)",
      cursor: "pointer",
      fontSize: 15,
      lineHeight: 1
    }
  }, "\u2715"));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
/** Hover/focus tooltip wrapper. */
function Tooltip({
  label,
  placement = "top",
  children,
  style = {}
}) {
  const [show, setShow] = React.useState(false);
  const pos = {
    top: {
      bottom: "calc(100% + 8px)",
      left: "50%",
      transform: "translateX(-50%)"
    },
    bottom: {
      top: "calc(100% + 8px)",
      left: "50%",
      transform: "translateX(-50%)"
    },
    left: {
      right: "calc(100% + 8px)",
      top: "50%",
      transform: "translateY(-50%)"
    },
    right: {
      left: "calc(100% + 8px)",
      top: "50%",
      transform: "translateY(-50%)"
    }
  }[placement];
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      display: "inline-flex",
      ...style
    },
    onMouseEnter: () => setShow(true),
    onMouseLeave: () => setShow(false),
    onFocus: () => setShow(true),
    onBlur: () => setShow(false)
  }, children, /*#__PURE__*/React.createElement("span", {
    role: "tooltip",
    style: {
      position: "absolute",
      ...pos,
      padding: "6px 10px",
      background: "var(--sr-ink)",
      color: "#fff",
      fontFamily: "var(--font-sans)",
      fontSize: "12.5px",
      fontWeight: 500,
      lineHeight: 1.3,
      borderRadius: "8px",
      whiteSpace: "nowrap",
      boxShadow: "var(--shadow-md)",
      opacity: show ? 1 : 0,
      visibility: show ? "visible" : "hidden",
      transition: "opacity var(--dur-fast) var(--ease-standard)",
      pointerEvents: "none",
      zIndex: 50
    }
  }, label));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Smartrplace Button — the primary interactive control.
 * Variants map to the CI "Elemente" button studies:
 *  - primary  : Tannengrün fill, white text
 *  - neon     : Neongrün fill, Dunkelgrün text (high-energy CTA, use once)
 *  - secondary: white fill, green text + border
 *  - ghost    : transparent, green text
 *  - inverse  : white fill on dark surfaces
 */
function Button({
  children,
  variant = "primary",
  size = "md",
  iconLeft = null,
  iconRight = null,
  fullWidth = false,
  disabled = false,
  type = "button",
  onClick,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: {
      height: "34px",
      padding: "0 16px",
      fontSize: "13px"
    },
    md: {
      height: "44px",
      padding: "0 22px",
      fontSize: "15px"
    },
    lg: {
      height: "54px",
      padding: "0 30px",
      fontSize: "16px"
    }
  };
  const base = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "9px",
    fontFamily: "var(--font-sans)",
    fontWeight: 600,
    letterSpacing: "0.01em",
    lineHeight: 1,
    borderRadius: "var(--radius-pill)",
    border: "1.5px solid transparent",
    cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? 0.5 : 1,
    width: fullWidth ? "100%" : "auto",
    transition: "background var(--dur-fast) var(--ease-standard), color var(--dur-fast) var(--ease-standard), border-color var(--dur-fast) var(--ease-standard), transform var(--dur-fast) var(--ease-standard)",
    ...sizes[size]
  };
  const variants = {
    primary: {
      background: "var(--brand)",
      color: "var(--text-inverse)"
    },
    neon: {
      background: "var(--accent)",
      color: "var(--accent-on)"
    },
    secondary: {
      background: "var(--surface-card)",
      color: "var(--text-brand)",
      borderColor: "var(--border-brand)"
    },
    ghost: {
      background: "transparent",
      color: "var(--text-brand)"
    },
    inverse: {
      background: "var(--surface-card)",
      color: "var(--text-brand)"
    }
  };
  const [hover, setHover] = React.useState(false);
  const hoverStyle = hover && !disabled ? {
    primary: {
      background: "var(--brand-hover)"
    },
    neon: {
      filter: "brightness(0.96)"
    },
    secondary: {
      background: "var(--surface-brand-soft)"
    },
    ghost: {
      background: "var(--surface-brand-soft)"
    },
    inverse: {
      background: "var(--sr-neutral-100)"
    }
  }[variant] : {};
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      ...base,
      ...variants[variant],
      ...hoverStyle,
      ...style
    }
  }, rest), iconLeft, children, iconRight);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Button.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Checkbox with label. Controlled or uncontrolled. */
function Checkbox({
  label,
  checked,
  defaultChecked,
  disabled = false,
  onChange,
  id,
  style = {},
  ...rest
}) {
  const reactId = React.useId();
  const inputId = id || reactId;
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "10px",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.55 : 1,
      fontFamily: "var(--font-sans)",
      fontSize: "15px",
      color: "var(--text-body)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    id: inputId,
    type: "checkbox",
    checked: checked,
    defaultChecked: defaultChecked,
    disabled: disabled,
    onChange: onChange,
    style: {
      appearance: "none",
      WebkitAppearance: "none",
      width: 20,
      height: 20,
      margin: 0,
      borderRadius: "6px",
      border: "1.5px solid var(--border-strong)",
      background: "var(--surface-card)",
      display: "grid",
      placeContent: "center",
      cursor: "inherit",
      transition: "background var(--dur-fast), border-color var(--dur-fast)"
    }
  }, rest)), label && /*#__PURE__*/React.createElement("span", null, label), /*#__PURE__*/React.createElement("style", null, `
        #${CSS.escape(inputId)}:checked {
          background: var(--brand);
          border-color: var(--brand);
        }
        #${CSS.escape(inputId)}:checked::after {
          content: "";
          width: 6px; height: 10px;
          border: solid #fff;
          border-width: 0 2px 2px 0;
          transform: rotate(45deg) translate(-1px,-1px);
        }
        #${CSS.escape(inputId)}:focus-visible {
          outline: none;
          box-shadow: var(--ring);
        }
      `));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Icon-only button. Square, rounded. Same variant language as Button.
 */
function IconButton({
  children,
  variant = "ghost",
  size = "md",
  disabled = false,
  "aria-label": ariaLabel,
  onClick,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: 34,
    md: 44,
    lg: 54
  };
  const dim = sizes[size];
  const [hover, setHover] = React.useState(false);
  const variants = {
    primary: {
      background: "var(--brand)",
      color: "var(--text-inverse)"
    },
    neon: {
      background: "var(--accent)",
      color: "var(--accent-on)"
    },
    secondary: {
      background: "var(--surface-card)",
      color: "var(--text-brand)",
      border: "1.5px solid var(--border-brand)"
    },
    ghost: {
      background: "transparent",
      color: "var(--text-body)"
    }
  };
  const hoverBg = {
    primary: {
      background: "var(--brand-hover)"
    },
    neon: {
      filter: "brightness(0.96)"
    },
    secondary: {
      background: "var(--surface-brand-soft)"
    },
    ghost: {
      background: "var(--sr-neutral-100)"
    }
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    "aria-label": ariaLabel,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      width: dim,
      height: dim,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      borderRadius: "var(--radius-md)",
      border: "1.5px solid transparent",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1,
      transition: "background var(--dur-fast) var(--ease-standard)",
      ...variants[variant],
      ...(hover && !disabled ? hoverBg[variant] : {}),
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Text input with optional label, helper text, error state and adornments.
 */
function Input({
  label,
  helperText,
  error = false,
  errorText,
  leadingIcon = null,
  trailingIcon = null,
  size = "md",
  id,
  style = {},
  disabled = false,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const reactId = React.useId();
  const inputId = id || reactId;
  const heights = {
    sm: "34px",
    md: "44px",
    lg: "54px"
  };
  const borderColor = error ? "var(--sr-danger)" : focus ? "var(--brand)" : "var(--border-default)";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "6px",
      width: "100%",
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "13px",
      fontWeight: 600,
      color: "var(--text-body)",
      letterSpacing: "0.01em"
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "8px",
      height: heights[size],
      padding: "0 14px",
      background: disabled ? "var(--sr-neutral-100)" : "var(--surface-card)",
      border: `1.5px solid ${borderColor}`,
      borderRadius: "var(--radius-md)",
      boxShadow: focus ? "var(--ring)" : "none",
      transition: "border-color var(--dur-fast), box-shadow var(--dur-fast)",
      opacity: disabled ? 0.6 : 1
    }
  }, leadingIcon && /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--text-subtle)",
      display: "inline-flex"
    }
  }, leadingIcon), /*#__PURE__*/React.createElement("input", _extends({
    id: inputId,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      border: "none",
      outline: "none",
      background: "transparent",
      fontFamily: "var(--font-sans)",
      fontSize: "15px",
      color: "var(--text-strong)",
      minWidth: 0
    }
  }, rest)), trailingIcon && /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--text-subtle)",
      display: "inline-flex"
    }
  }, trailingIcon)), (helperText || error && errorText) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "12.5px",
      color: error ? "var(--sr-danger)" : "var(--text-muted)"
    }
  }, error && errorText ? errorText : helperText));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Radio button with label. Group by shared `name`. */
function Radio({
  label,
  checked,
  defaultChecked,
  disabled = false,
  name,
  value,
  onChange,
  id,
  style = {},
  ...rest
}) {
  const reactId = React.useId();
  const inputId = id || reactId;
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "10px",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.55 : 1,
      fontFamily: "var(--font-sans)",
      fontSize: "15px",
      color: "var(--text-body)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    id: inputId,
    type: "radio",
    name: name,
    value: value,
    checked: checked,
    defaultChecked: defaultChecked,
    disabled: disabled,
    onChange: onChange,
    style: {
      appearance: "none",
      WebkitAppearance: "none",
      width: 20,
      height: 20,
      margin: 0,
      borderRadius: "50%",
      border: "1.5px solid var(--border-strong)",
      background: "var(--surface-card)",
      display: "grid",
      placeContent: "center",
      cursor: "inherit",
      transition: "border-color var(--dur-fast)"
    }
  }, rest)), label && /*#__PURE__*/React.createElement("span", null, label), /*#__PURE__*/React.createElement("style", null, `
        #${CSS.escape(inputId)}:checked {
          border-color: var(--brand);
          border-width: 6px;
        }
        #${CSS.escape(inputId)}:focus-visible {
          outline: none;
          box-shadow: var(--ring);
        }
      `));
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Native-backed select with brand styling and a chevron. */
function Select({
  label,
  helperText,
  options = [],
  size = "md",
  id,
  disabled = false,
  style = {},
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const reactId = React.useId();
  const inputId = id || reactId;
  const heights = {
    sm: "34px",
    md: "44px",
    lg: "54px"
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "6px",
      width: "100%",
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "13px",
      fontWeight: 600,
      color: "var(--text-body)"
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    id: inputId,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      width: "100%",
      height: heights[size],
      padding: "0 40px 0 14px",
      appearance: "none",
      WebkitAppearance: "none",
      background: disabled ? "var(--sr-neutral-100)" : "var(--surface-card)",
      border: `1.5px solid ${focus ? "var(--brand)" : "var(--border-default)"}`,
      borderRadius: "var(--radius-md)",
      boxShadow: focus ? "var(--ring)" : "none",
      fontFamily: "var(--font-sans)",
      fontSize: "15px",
      color: "var(--text-strong)",
      outline: "none",
      cursor: disabled ? "not-allowed" : "pointer",
      transition: "border-color var(--dur-fast), box-shadow var(--dur-fast)"
    }
  }, rest), options.map(o => {
    const value = typeof o === "string" ? o : o.value;
    const text = typeof o === "string" ? o : o.label;
    return /*#__PURE__*/React.createElement("option", {
      key: value,
      value: value
    }, text);
  })), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: "absolute",
      right: 14,
      top: "50%",
      transform: "translateY(-50%)",
      pointerEvents: "none",
      color: "var(--text-muted)",
      fontSize: 12
    }
  }, "\u25BE")), helperText && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "12.5px",
      color: "var(--text-muted)"
    }
  }, helperText));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Toggle switch. Controlled or uncontrolled. */
function Switch({
  label,
  checked,
  defaultChecked = false,
  disabled = false,
  onChange,
  style = {},
  ...rest
}) {
  const isControlled = checked !== undefined;
  const [internal, setInternal] = React.useState(defaultChecked);
  const on = isControlled ? checked : internal;
  const toggle = e => {
    if (disabled) return;
    if (!isControlled) setInternal(v => !v);
    onChange && onChange(!on, e);
  };
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "12px",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.55 : 1,
      fontFamily: "var(--font-sans)",
      fontSize: "15px",
      color: "var(--text-body)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    role: "switch",
    "aria-checked": on,
    disabled: disabled,
    onClick: toggle,
    style: {
      width: 44,
      height: 26,
      borderRadius: 999,
      border: "none",
      padding: 3,
      background: on ? "var(--brand)" : "var(--sr-neutral-300)",
      display: "inline-flex",
      alignItems: "center",
      cursor: "inherit",
      transition: "background var(--dur-base) var(--ease-standard)"
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 20,
      height: 20,
      borderRadius: "50%",
      background: "#fff",
      boxShadow: "var(--shadow-sm)",
      transform: on ? "translateX(18px)" : "translateX(0)",
      transition: "transform var(--dur-base) var(--ease-out)"
    }
  })), label && /*#__PURE__*/React.createElement("span", null, label));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/forms/Textarea.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Multi-line text input matching Input's styling. */
function Textarea({
  label,
  helperText,
  error = false,
  errorText,
  rows = 4,
  id,
  disabled = false,
  style = {},
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const reactId = React.useId();
  const inputId = id || reactId;
  const borderColor = error ? "var(--sr-danger)" : focus ? "var(--brand)" : "var(--border-default)";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "6px",
      width: "100%",
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "13px",
      fontWeight: 600,
      color: "var(--text-body)"
    }
  }, label), /*#__PURE__*/React.createElement("textarea", _extends({
    id: inputId,
    rows: rows,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      width: "100%",
      boxSizing: "border-box",
      padding: "12px 14px",
      background: disabled ? "var(--sr-neutral-100)" : "var(--surface-card)",
      border: `1.5px solid ${borderColor}`,
      borderRadius: "var(--radius-md)",
      boxShadow: focus ? "var(--ring)" : "none",
      fontFamily: "var(--font-sans)",
      fontSize: "15px",
      lineHeight: 1.5,
      color: "var(--text-strong)",
      outline: "none",
      resize: "vertical",
      transition: "border-color var(--dur-fast), box-shadow var(--dur-fast)"
    }
  }, rest)), (helperText || error && errorText) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "12.5px",
      color: error ? "var(--sr-danger)" : "var(--text-muted)"
    }
  }, error && errorText ? errorText : helperText));
}
Object.assign(__ds_scope, { Textarea });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Textarea.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Breadcrumb.jsx
try { (() => {
/** Breadcrumb trail. `items` is an array of { label, href? }. */
function Breadcrumb({
  items = [],
  style = {}
}) {
  return /*#__PURE__*/React.createElement("nav", {
    "aria-label": "Breadcrumb",
    style: {
      display: "flex",
      alignItems: "center",
      flexWrap: "wrap",
      gap: "8px",
      fontFamily: "var(--font-sans)",
      fontSize: "13.5px",
      ...style
    }
  }, items.map((it, i) => {
    const last = i === items.length - 1;
    return /*#__PURE__*/React.createElement(React.Fragment, {
      key: i
    }, it.href && !last ? /*#__PURE__*/React.createElement("a", {
      href: it.href,
      style: {
        color: "var(--text-muted)",
        textDecoration: "none"
      }
    }, it.label) : /*#__PURE__*/React.createElement("span", {
      style: {
        color: last ? "var(--text-strong)" : "var(--text-muted)",
        fontWeight: last ? 600 : 400
      }
    }, it.label), !last && /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--text-subtle)"
      }
    }, "/"));
  }));
}
Object.assign(__ds_scope, { Breadcrumb });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Breadcrumb.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
/**
 * Tab bar. Controlled (`value` + `onChange`) or uncontrolled (`defaultValue`).
 * `tabs` is an array of { value, label, icon? }.
 */
function Tabs({
  tabs = [],
  value,
  defaultValue,
  onChange,
  style = {}
}) {
  const isControlled = value !== undefined;
  const [internal, setInternal] = React.useState(defaultValue ?? tabs[0]?.value);
  const active = isControlled ? value : internal;
  const select = v => {
    if (!isControlled) setInternal(v);
    onChange && onChange(v);
  };
  return /*#__PURE__*/React.createElement("div", {
    role: "tablist",
    style: {
      display: "inline-flex",
      gap: "4px",
      borderBottom: "1px solid var(--border-subtle)",
      ...style
    }
  }, tabs.map(t => {
    const on = t.value === active;
    return /*#__PURE__*/React.createElement("button", {
      key: t.value,
      role: "tab",
      "aria-selected": on,
      onClick: () => select(t.value),
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: "8px",
        padding: "10px 14px",
        border: "none",
        background: "transparent",
        cursor: "pointer",
        fontFamily: "var(--font-sans)",
        fontSize: "14.5px",
        fontWeight: on ? 600 : 500,
        color: on ? "var(--text-brand)" : "var(--text-muted)",
        borderBottom: `2px solid ${on ? "var(--brand)" : "transparent"}`,
        marginBottom: "-1px",
        transition: "color var(--dur-fast)"
      }
    }, t.icon, t.label);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dashboard/Overview.jsx
try { (() => {
// Smartrplace dashboard — Overview screen
function Overview({
  setRoute
}) {
  const energy = [42, 40, 44, 39, 36, 33, 35, 31, 29, 30, 27, 25, 26, 24, 22, 23, 21, 20];
  const buildings = [{
    name: "Hauptstraße 12",
    city: "Berlin",
    use: 1204,
    delta: "-18%",
    status: "optimized"
  }, {
    name: "Werkstraße 4",
    city: "Leipzig",
    use: 2380,
    delta: "-9%",
    status: "optimized"
  }, {
    name: "Am Park 7",
    city: "Dresden",
    use: 980,
    delta: "+2%",
    status: "attention"
  }, {
    name: "Ringallee 22",
    city: "Berlin",
    use: 1642,
    delta: "-14%",
    status: "optimized"
  }, {
    name: "Seeweg 1",
    city: "Potsdam",
    use: 512,
    delta: "—",
    status: "offline"
  }];
  const statusMap = {
    optimized: {
      tone: "success",
      label: "Optimized"
    },
    attention: {
      tone: "warning",
      label: "Attention"
    },
    offline: {
      tone: "danger",
      label: "Offline"
    }
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 32,
      display: "grid",
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(4,1fr)",
      gap: 18
    }
  }, /*#__PURE__*/React.createElement(Card, {
    variant: "elevated"
  }, /*#__PURE__*/React.createElement(Metric, {
    label: "Portfolio energy",
    value: "8.7",
    unit: "MWh",
    delta: "-13%",
    hint: "this month"
  })), /*#__PURE__*/React.createElement(Card, {
    variant: "elevated"
  }, /*#__PURE__*/React.createElement(Metric, {
    label: "Estimated savings",
    value: "\u20AC 3 240",
    delta: "-18%",
    hint: "vs. baseline"
  })), /*#__PURE__*/React.createElement(Card, {
    variant: "elevated"
  }, /*#__PURE__*/React.createElement(Metric, {
    label: "Buildings online",
    value: "24 / 26",
    delta: "2 offline",
    deltaTone: "negative"
  })), /*#__PURE__*/React.createElement(Card, {
    variant: "elevated"
  }, /*#__PURE__*/React.createElement(Metric, {
    label: "CO\u2082 avoided",
    value: "4.1",
    unit: "t",
    delta: "+0.6",
    deltaTone: "positive",
    hint: "this month"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1.7fr 1fr",
      gap: 18
    }
  }, /*#__PURE__*/React.createElement(Card, {
    variant: "elevated",
    padding: "24px"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      textTransform: "uppercase",
      letterSpacing: "0.16em",
      fontSize: 11,
      color: "var(--text-brand)"
    }
  }, "Consumption trend"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 26,
      color: "var(--text-strong)",
      marginTop: 6
    }
  }, "8.7 ", /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15,
      color: "var(--text-muted)"
    }
  }, "MWh"))), /*#__PURE__*/React.createElement(Tabs, {
    defaultValue: "30d",
    tabs: [{
      value: "7d",
      label: "7d"
    }, {
      value: "30d",
      label: "30d"
    }, {
      value: "12m",
      label: "12m"
    }]
  })), /*#__PURE__*/React.createElement(AreaChart, {
    data: energy
  })), /*#__PURE__*/React.createElement(Card, {
    variant: "elevated",
    padding: "24px"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      textTransform: "uppercase",
      letterSpacing: "0.16em",
      fontSize: 11,
      color: "var(--text-brand)",
      marginBottom: 16
    }
  }, "Active alerts"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Alert, {
    tone: "warning",
    title: "Setpoint above target"
  }, "Am Park 7 \xB7 +2.5\xB0C over schedule"), /*#__PURE__*/React.createElement(Alert, {
    tone: "danger",
    title: "Gateway offline"
  }, "Seeweg 1 \xB7 no data for 42 min"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement(ProgressBar, {
    value: 41,
    tone: "success",
    label: "Optimization coverage",
    showValue: true
  }))))), /*#__PURE__*/React.createElement(Card, {
    variant: "elevated",
    padding: "0"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      padding: "20px 24px",
      borderBottom: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 20,
      margin: 0,
      color: "var(--text-strong)"
    }
  }, "Buildings"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    onClick: () => setRoute("building"),
    iconRight: /*#__PURE__*/React.createElement("i", {
      "data-lucide": "arrow-right",
      style: {
        width: 16,
        height: 16
      }
    })
  }, "View all")), /*#__PURE__*/React.createElement("table", {
    style: {
      width: "100%",
      borderCollapse: "collapse",
      fontFamily: "var(--font-sans)"
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
    style: {
      textAlign: "left",
      color: "var(--text-subtle)",
      fontSize: 11,
      textTransform: "uppercase",
      letterSpacing: "0.08em"
    }
  }, /*#__PURE__*/React.createElement("th", {
    style: {
      padding: "12px 24px",
      fontWeight: 600
    }
  }, "Building"), /*#__PURE__*/React.createElement("th", {
    style: {
      padding: "12px 16px",
      fontWeight: 600
    }
  }, "Location"), /*#__PURE__*/React.createElement("th", {
    style: {
      padding: "12px 16px",
      fontWeight: 600,
      textAlign: "right"
    }
  }, "kWh / mo"), /*#__PURE__*/React.createElement("th", {
    style: {
      padding: "12px 16px",
      fontWeight: 600,
      textAlign: "right"
    }
  }, "\u0394"), /*#__PURE__*/React.createElement("th", {
    style: {
      padding: "12px 24px",
      fontWeight: 600
    }
  }, "Status"))), /*#__PURE__*/React.createElement("tbody", null, buildings.map(b => /*#__PURE__*/React.createElement("tr", {
    key: b.name,
    onClick: () => setRoute("building"),
    style: {
      borderTop: "1px solid var(--border-subtle)",
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "14px 24px",
      fontWeight: 600,
      color: "var(--text-strong)",
      fontSize: 14.5
    }
  }, b.name), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "14px 16px",
      color: "var(--text-muted)",
      fontSize: 14
    }
  }, b.city), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "14px 16px",
      textAlign: "right",
      fontFamily: "var(--font-mono)",
      color: "var(--text-body)"
    }
  }, b.use.toLocaleString()), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "14px 16px",
      textAlign: "right",
      fontFamily: "var(--font-mono)",
      color: b.delta.startsWith("-") ? "var(--sr-success)" : b.delta.startsWith("+") ? "var(--sr-danger)" : "var(--text-subtle)"
    }
  }, b.delta), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: "14px 24px"
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: statusMap[b.status].tone
  }, statusMap[b.status].label))))))));
}
Object.assign(window, {
  Overview
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dashboard/Overview.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dashboard/Screens.jsx
try { (() => {
// Smartrplace dashboard — Building detail + Schedule screens
function Building() {
  const load = [21, 20, 20, 19, 19, 20, 22, 24, 23, 22, 21, 21, 22, 23, 24, 25, 24, 23, 22, 21, 21, 20, 20, 19];
  const [tab, setTab] = React.useState("energy");
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 32,
      display: "grid",
      gap: 22
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3,1fr)",
      gap: 18
    }
  }, /*#__PURE__*/React.createElement(Card, {
    variant: "elevated"
  }, /*#__PURE__*/React.createElement(Metric, {
    label: "Energy this month",
    value: "1 204",
    unit: "kWh",
    delta: "-18%",
    hint: "vs. last year"
  })), /*#__PURE__*/React.createElement(Card, {
    variant: "elevated"
  }, /*#__PURE__*/React.createElement(Metric, {
    label: "Indoor temperature",
    value: "21.5",
    unit: "\xB0C",
    delta: "+0.3",
    deltaTone: "neutral",
    hint: "setpoint 21\xB0C"
  })), /*#__PURE__*/React.createElement(Card, {
    variant: "elevated"
  }, /*#__PURE__*/React.createElement(Metric, {
    label: "Comfort index",
    value: "94",
    unit: "%",
    delta: "+3",
    deltaTone: "positive"
  }))), /*#__PURE__*/React.createElement(Card, {
    variant: "elevated",
    padding: "0"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "18px 24px 0"
    }
  }, /*#__PURE__*/React.createElement(Tabs, {
    value: tab,
    onChange: setTab,
    tabs: [{
      value: "energy",
      label: "Energy"
    }, {
      value: "comfort",
      label: "Comfort"
    }, {
      value: "devices",
      label: "Devices"
    }]
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 24
    }
  }, tab === "devices" ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: 10
    }
  }, [["Heating circuit A", "thermometer", "Online", "success"], ["Ventilation zone 1", "wind", "Online", "success"], ["Smart meter", "gauge", "Online", "success"], ["Gateway B-04", "router", "Syncing", "warning"]].map(([n, ic, st, tone]) => /*#__PURE__*/React.createElement("div", {
    key: n,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 14,
      padding: "14px 16px",
      border: "1px solid var(--border-subtle)",
      borderRadius: "var(--radius-md)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 40,
      height: 40,
      borderRadius: 10,
      background: "var(--surface-brand-soft)",
      display: "grid",
      placeContent: "center",
      color: "var(--sr-tannengruen)"
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": ic,
    style: {
      width: 20,
      height: 20
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontFamily: "var(--font-sans)",
      fontWeight: 600,
      color: "var(--text-strong)"
    }
  }, n), /*#__PURE__*/React.createElement(Badge, {
    tone: tone
  }, st)))) : /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      textTransform: "uppercase",
      letterSpacing: "0.16em",
      fontSize: 11,
      color: "var(--text-brand)",
      marginBottom: 6
    }
  }, tab === "energy" ? "Hourly load" : "Temperature (24h)"), /*#__PURE__*/React.createElement(AreaChart, {
    data: load,
    tone: tab === "comfort" ? "var(--sr-hellgruen)" : "var(--sr-tannengruen)"
  })))), /*#__PURE__*/React.createElement(Card, {
    variant: "brand",
    padding: "26px"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      textTransform: "uppercase",
      letterSpacing: "0.18em",
      fontSize: 11,
      color: "var(--sr-neongruen)",
      marginBottom: 8
    }
  }, "Optimization"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 24,
      lineHeight: 1
    }
  }, "Smartrplace is managing this building autonomously.")), /*#__PURE__*/React.createElement(Switch, {
    defaultChecked: true
  }))));
}
function Schedule() {
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 32,
      display: "grid",
      gridTemplateColumns: "1.4fr 1fr",
      gap: 22,
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement(Card, {
    variant: "elevated",
    padding: "24px"
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 20,
      margin: "0 0 4px",
      color: "var(--text-strong)"
    }
  }, "Weekly heating schedule"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      color: "var(--text-muted)",
      margin: "0 0 20px"
    }
  }, "Comfort windows in Tannengr\xFCn, setback in grey."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: 8
    }
  }, days.map((d, i) => /*#__PURE__*/React.createElement("div", {
    key: d,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 38,
      fontFamily: "var(--font-sans)",
      fontSize: 13,
      color: "var(--text-muted)"
    }
  }, d), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      height: 22,
      borderRadius: 6,
      background: "var(--sr-neutral-200)",
      position: "relative",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: `${i > 4 ? 30 : 26}%`,
      width: `${i > 4 ? 30 : 44}%`,
      top: 0,
      bottom: 0,
      background: "var(--sr-tannengruen)",
      borderRadius: 6
    }
  })))))), /*#__PURE__*/React.createElement(Card, {
    variant: "elevated",
    padding: "24px"
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 20,
      margin: "0 0 18px",
      color: "var(--text-strong)"
    }
  }, "Settings"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: 18
    }
  }, /*#__PURE__*/React.createElement(Select, {
    label: "Mode",
    options: ["Eco", "Comfort", "Custom"]
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Comfort setpoint",
    defaultValue: "21.0 \xB0C"
  }), /*#__PURE__*/React.createElement(Switch, {
    label: "Night setback",
    defaultChecked: true
  }), /*#__PURE__*/React.createElement(Switch, {
    label: "Weather compensation",
    defaultChecked: true
  }), /*#__PURE__*/React.createElement(Switch, {
    label: "Weekend schedule"
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    fullWidth: true
  }, "Save schedule"))));
}
Object.assign(window, {
  Building,
  Schedule
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dashboard/Screens.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dashboard/Shell.jsx
try { (() => {
// Smartrplace dashboard — app shell (sidebar + topbar)
function Sidebar({
  route,
  setRoute
}) {
  const items = [{
    id: "overview",
    icon: "layout-dashboard",
    label: "Overview"
  }, {
    id: "building",
    icon: "building-2",
    label: "Buildings"
  }, {
    id: "energy",
    icon: "gauge",
    label: "Energy"
  }, {
    id: "schedule",
    icon: "calendar-clock",
    label: "Schedules"
  }, {
    id: "alerts",
    icon: "bell",
    label: "Alerts"
  }];
  return /*#__PURE__*/React.createElement("aside", {
    style: {
      width: 244,
      flexShrink: 0,
      background: "var(--sr-dunkelgruen)",
      color: "#fff",
      display: "flex",
      flexDirection: "column",
      padding: "22px 16px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      padding: "6px 10px 24px"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logos/smartrplace-wordmark-white.svg",
    alt: "Smartrplace",
    style: {
      height: 52,
      width: 142,
      marginTop: 2
    }
  })), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "grid",
      gap: 4
    }
  }, items.map(it => {
    const on = route === it.id;
    return /*#__PURE__*/React.createElement("button", {
      key: it.id,
      onClick: () => setRoute(it.id),
      style: {
        display: "flex",
        alignItems: "center",
        gap: 12,
        padding: "11px 12px",
        border: "none",
        borderRadius: "var(--radius-md)",
        cursor: "pointer",
        textAlign: "left",
        background: on ? "rgba(189,255,120,0.14)" : "transparent",
        color: on ? "var(--sr-neongruen)" : "rgba(255,255,255,0.74)",
        fontFamily: "var(--font-sans)",
        fontSize: 14.5,
        fontWeight: on ? 600 : 500
      }
    }, /*#__PURE__*/React.createElement("i", {
      "data-lucide": it.icon,
      style: {
        width: 19,
        height: 19
      }
    }), it.label);
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "auto",
      padding: "16px 12px",
      borderTop: "1px solid rgba(255,255,255,0.12)",
      display: "flex",
      alignItems: "center",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: "Lena Vogt",
    size: 34
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      lineHeight: 1.2
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 13.5,
      fontWeight: 600
    }
  }, "Lena Vogt"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 12,
      color: "rgba(255,255,255,0.6)"
    }
  }, "Portfolio manager"))));
}
function Topbar({
  title,
  crumb
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "20px 32px",
      borderBottom: "1px solid var(--border-subtle)",
      background: "var(--surface-card)"
    }
  }, /*#__PURE__*/React.createElement("div", null, crumb, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 30,
      lineHeight: 1,
      margin: "8px 0 0",
      color: "var(--text-strong)"
    }
  }, title)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement(Input, {
    placeholder: "Search buildings\u2026",
    leadingIcon: /*#__PURE__*/React.createElement("i", {
      "data-lucide": "search",
      style: {
        width: 16,
        height: 16
      }
    }),
    style: {
      width: 240
    }
  })), /*#__PURE__*/React.createElement(IconButton, {
    "aria-label": "Notifications",
    variant: "secondary"
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "bell",
    style: {
      width: 18,
      height: 18
    }
  })), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "sm",
    iconLeft: /*#__PURE__*/React.createElement("i", {
      "data-lucide": "plus",
      style: {
        width: 16,
        height: 16
      }
    })
  }, "Add building")));
}

// simple area chart (data viz, inline SVG)
function AreaChart({
  data,
  height = 160,
  tone = "var(--sr-tannengruen)"
}) {
  const w = 640,
    h = height,
    pad = 8;
  const max = Math.max(...data),
    min = Math.min(...data);
  const pts = data.map((v, i) => {
    const x = pad + i / (data.length - 1) * (w - pad * 2);
    const y = pad + (1 - (v - min) / (max - min || 1)) * (h - pad * 2);
    return [x, y];
  });
  const line = pts.map((p, i) => (i ? "L" : "M") + p[0].toFixed(1) + " " + p[1].toFixed(1)).join(" ");
  const area = line + ` L ${w - pad} ${h - pad} L ${pad} ${h - pad} Z`;
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: `0 0 ${w} ${h}`,
    style: {
      width: "100%",
      height,
      display: "block"
    },
    preserveAspectRatio: "none"
  }, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: "ag",
    x1: "0",
    y1: "0",
    x2: "0",
    y2: "1"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "0%",
    stopColor: tone,
    stopOpacity: "0.20"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "100%",
    stopColor: tone,
    stopOpacity: "0"
  }))), /*#__PURE__*/React.createElement("path", {
    d: area,
    fill: "url(#ag)"
  }), /*#__PURE__*/React.createElement("path", {
    d: line,
    fill: "none",
    stroke: tone,
    strokeWidth: "2.5",
    strokeLinejoin: "round",
    strokeLinecap: "round"
  }));
}
Object.assign(window, {
  Sidebar,
  Topbar,
  AreaChart
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dashboard/Shell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Chrome.jsx
try { (() => {
// Smartrplace marketing site — shared header / nav
function SiteHeader({
  route,
  setRoute
}) {
  const nav = [{
    id: "home",
    label: "Home"
  }, {
    id: "solutions",
    label: "Solutions"
  }, {
    id: "ecosystem",
    label: "Ecosystem"
  }, {
    id: "contact",
    label: "Contact"
  }];
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: "sticky",
      top: 0,
      zIndex: 40,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "18px clamp(20px, 5vw, 64px)",
      background: "rgba(251,251,248,0.82)",
      backdropFilter: "blur(10px)",
      borderBottom: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      setRoute("home");
    },
    style: {
      display: "flex",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logos/smartrplace-wordmark.svg",
    alt: "Smartrplace",
    style: {
      height: 30
    }
  })), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "flex",
      gap: 4
    }
  }, nav.map(n => /*#__PURE__*/React.createElement("a", {
    key: n.id,
    href: "#",
    onClick: e => {
      e.preventDefault();
      setRoute(n.id);
    },
    style: {
      padding: "8px 14px",
      borderRadius: 999,
      textDecoration: "none",
      fontFamily: "var(--font-sans)",
      fontSize: 14.5,
      fontWeight: route === n.id ? 600 : 500,
      color: route === n.id ? "var(--text-brand)" : "var(--text-muted)",
      background: route === n.id ? "var(--surface-brand-soft)" : "transparent"
    }
  }, n.label))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm"
  }, "Log in"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "sm",
    iconRight: /*#__PURE__*/React.createElement("i", {
      "data-lucide": "arrow-right",
      style: {
        width: 16,
        height: 16
      }
    })
  }, "Book a demo")));
}
function SiteFooter() {
  const cols = [{
    h: "Product",
    items: ["Energy management", "Space management", "Hardware", "Integrations"]
  }, {
    h: "Company",
    items: ["About", "Research", "Careers", "Press"]
  }, {
    h: "Resources",
    items: ["Docs", "Case studies", "Support", "Status"]
  }];
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: "var(--sr-dunkelgruen)",
      color: "#fff",
      padding: "64px clamp(20px,5vw,64px) 40px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1.4fr repeat(3, 1fr)",
      gap: 40,
      maxWidth: 1200,
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logos/smartrplace-wordmark-white.svg",
    alt: "Smartrplace",
    style: {
      height: 28
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      lineHeight: 1.6,
      color: "rgba(255,255,255,0.7)",
      marginTop: 18,
      maxWidth: 280
    }
  }, "All in one ecosystem for energy and space management. Research-born, environment-centered.")), cols.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.h
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      textTransform: "uppercase",
      letterSpacing: "0.16em",
      fontSize: 12,
      color: "var(--sr-neongruen)",
      marginBottom: 16
    }
  }, c.h), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: "none",
      padding: 0,
      margin: 0,
      display: "grid",
      gap: 10
    }
  }, c.items.map(i => /*#__PURE__*/React.createElement("li", {
    key: i
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: "rgba(255,255,255,0.78)",
      textDecoration: "none",
      fontSize: 14,
      fontFamily: "var(--font-sans)"
    }
  }, i))))))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: "40px auto 0",
      paddingTop: 24,
      borderTop: "1px solid rgba(255,255,255,0.14)",
      display: "flex",
      justifyContent: "space-between",
      color: "rgba(255,255,255,0.55)",
      fontSize: 13,
      fontFamily: "var(--font-sans)"
    }
  }, /*#__PURE__*/React.createElement("span", null, "\xA9 2026 Smartrplace GmbH"), /*#__PURE__*/React.createElement("span", null, "Upgrade your Building. Space. Future.")));
}
Object.assign(window, {
  SiteHeader,
  SiteFooter
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Chrome.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Home.jsx
try { (() => {
// Smartrplace marketing — Home route
function Home({
  setRoute
}) {
  const features = [{
    icon: "gauge",
    title: "Energy management",
    body: "Continuous optimization of heating, ventilation and power — measurable savings from day one."
  }, {
    icon: "layout-grid",
    title: "Space management",
    body: "One view across every building and room. Private or commercial, all in one place."
  }, {
    icon: "cpu",
    title: "Hardware in symbiosis",
    body: "Gateways and sensors that speak to your existing systems — no rip-and-replace."
  }];
  const stats = [{
    v: "-18%",
    l: "average energy reduction"
  }, {
    v: "26",
    l: "buildings per portfolio"
  }, {
    v: "24/7",
    l: "autonomous optimization"
  }];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("section", {
    style: {
      position: "relative",
      overflow: "hidden",
      background: "var(--sr-tannengruen)",
      color: "#fff",
      padding: "clamp(64px,9vw,120px) clamp(20px,5vw,64px) clamp(72px,10vw,132px)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    id: "heroPattern",
    style: {
      position: "absolute",
      inset: 0,
      opacity: 0.10,
      pointerEvents: "none"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      maxWidth: 1100,
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      textTransform: "uppercase",
      letterSpacing: "0.24em",
      fontSize: 13,
      color: "var(--sr-neongruen)",
      marginBottom: 26
    }
  }, "All in one ecosystem"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "clamp(48px,8vw,104px)",
      lineHeight: 0.86,
      letterSpacing: "0.01em",
      margin: 0,
      maxWidth: 900
    }
  }, "Upgrade your", /*#__PURE__*/React.createElement("br", null), "Building. ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--sr-neongruen)"
    }
  }, "Space."), " Future."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "clamp(16px,1.6vw,20px)",
      lineHeight: 1.5,
      color: "rgba(255,255,255,0.82)",
      maxWidth: 560,
      margin: "30px 0 0"
    }
  }, "Smartrplace supports your daily space management \u2014 bringing hardware and software into symbiosis to save energy and cost."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 14,
      marginTop: 40,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "neon",
    size: "lg",
    iconRight: /*#__PURE__*/React.createElement("i", {
      "data-lucide": "arrow-right",
      style: {
        width: 18,
        height: 18
      }
    })
  }, "Book a demo"), /*#__PURE__*/React.createElement(Button, {
    variant: "inverse",
    size: "lg",
    onClick: () => setRoute("solutions")
  }, "Explore solutions")))), /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--sr-dunkelgruen)",
      color: "#fff",
      padding: "34px clamp(20px,5vw,64px)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1100,
      margin: "0 auto",
      display: "grid",
      gridTemplateColumns: "repeat(3,1fr)",
      gap: 24
    }
  }, stats.map(s => /*#__PURE__*/React.createElement("div", {
    key: s.l,
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 40,
      fontWeight: 500,
      color: "var(--sr-neongruen)"
    }
  }, s.v), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      color: "rgba(255,255,255,0.72)"
    }
  }, s.l))))), /*#__PURE__*/React.createElement("section", {
    style: {
      padding: "clamp(64px,8vw,110px) clamp(20px,5vw,64px)",
      background: "var(--surface-page)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1100,
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      textTransform: "uppercase",
      letterSpacing: "0.22em",
      fontSize: 12,
      color: "var(--text-brand)",
      marginBottom: 14
    }
  }, "Technology with purpose"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "clamp(30px,4vw,52px)",
      lineHeight: 0.95,
      margin: "0 0 12px",
      color: "var(--text-strong)",
      maxWidth: 640
    }
  }, "Environment-centered, from sensor to dashboard."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3,1fr)",
      gap: 22,
      marginTop: 48
    }
  }, features.map(f => /*#__PURE__*/React.createElement(Card, {
    key: f.title,
    variant: "elevated",
    padding: "28px"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 48,
      height: 48,
      borderRadius: 14,
      background: "var(--surface-brand-soft)",
      display: "grid",
      placeContent: "center",
      color: "var(--sr-tannengruen)",
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": f.icon,
    style: {
      width: 24,
      height: 24
    }
  })), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 22,
      margin: "0 0 10px",
      color: "var(--text-strong)"
    }
  }, f.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 15,
      lineHeight: 1.5,
      color: "var(--text-muted)",
      margin: 0
    }
  }, f.body)))))), /*#__PURE__*/React.createElement("section", {
    style: {
      padding: "0 clamp(20px,5vw,64px) clamp(64px,8vw,110px)",
      background: "var(--surface-page)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1100,
      margin: "0 auto",
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 40,
      alignItems: "center",
      background: "var(--surface-card)",
      borderRadius: "var(--radius-xl)",
      border: "1px solid var(--border-subtle)",
      boxShadow: "var(--shadow-md)",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "clamp(32px,4vw,56px)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      textTransform: "uppercase",
      letterSpacing: "0.2em",
      fontSize: 12,
      color: "var(--text-brand)",
      marginBottom: 14
    }
  }, "Research-born innovation"), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "clamp(26px,3vw,38px)",
      lineHeight: 0.98,
      margin: "0 0 16px",
      color: "var(--text-strong)"
    }
  }, "Homogeneous by design, open by principle."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 15.5,
      lineHeight: 1.55,
      color: "var(--text-muted)",
      margin: "0 0 22px"
    }
  }, "The ecosystem understands technologies in symbiosis \u2014 combining hardware and software without deep cuts to what you already run."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: 8
    }
  }, ["Heating", "Ventilation", "Metering", "Gateways", "Schedules"].map(t => /*#__PURE__*/React.createElement(Tag, {
    key: t
  }, t)))), /*#__PURE__*/React.createElement("div", {
    style: {
      alignSelf: "stretch",
      background: "var(--brand-gradient)",
      position: "relative",
      overflow: "hidden",
      minHeight: 340,
      display: "grid",
      placeItems: "center"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logos/smartrplace-signet-neon.png",
    alt: "",
    style: {
      width: "56%",
      opacity: 0.95
    }
  })))), /*#__PURE__*/React.createElement(CTASection, {
    setRoute: setRoute
  }));
}
function CTASection({
  setRoute
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--sr-neongruen)",
      padding: "clamp(56px,7vw,96px) clamp(20px,5vw,64px)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 900,
      margin: "0 auto",
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "clamp(30px,4.5vw,56px)",
      lineHeight: 0.92,
      margin: "0 0 20px",
      color: "var(--sr-dunkelgruen)"
    }
  }, "Save energy. Start the upgrade."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 17,
      color: "rgba(3,55,42,0.72)",
      margin: "0 0 32px"
    }
  }, "See Smartrplace on your own portfolio in a 30-minute walkthrough."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 14,
      justifyContent: "center",
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    onClick: () => setRoute("contact")
  }, "Book a demo"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "lg",
    onClick: () => setRoute("solutions")
  }, "See solutions"))));
}
Object.assign(window, {
  Home
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Home.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Pages.jsx
try { (() => {
// Smartrplace marketing — Solutions & Ecosystem & Contact routes
function Solutions() {
  const rows = [{
    icon: "gauge",
    title: "Energy management",
    body: "Optimize heating, cooling and power continuously. Set budgets, schedules and night setback across your whole portfolio.",
    points: ["Automated setpoint control", "Weather-compensated heating", "Consumption analytics"]
  }, {
    icon: "layout-grid",
    title: "Space management",
    body: "A universal model for private and commercial spaces — rooms, zones, buildings and sites in one hierarchy.",
    points: ["Occupancy-aware control", "Comfort monitoring", "Portfolio roll-ups"]
  }, {
    icon: "cpu",
    title: "Hardware",
    body: "Gateways and sensors designed to integrate, not replace. Connect what you already run.",
    points: ["Retrofit-friendly gateways", "Open protocols", "Secure edge devices"]
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface-page)"
    }
  }, /*#__PURE__*/React.createElement("section", {
    style: {
      padding: "clamp(56px,7vw,96px) clamp(20px,5vw,64px) 40px",
      maxWidth: 1100,
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      textTransform: "uppercase",
      letterSpacing: "0.22em",
      fontSize: 12,
      color: "var(--text-brand)",
      marginBottom: 16
    }
  }, "Solutions"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "clamp(38px,5.5vw,72px)",
      lineHeight: 0.9,
      margin: 0,
      color: "var(--text-strong)",
      maxWidth: 760
    }
  }, "One ecosystem for every part of the building.")), /*#__PURE__*/React.createElement("section", {
    style: {
      padding: "20px clamp(20px,5vw,64px) clamp(56px,7vw,96px)",
      maxWidth: 1100,
      margin: "0 auto",
      display: "grid",
      gap: 20
    }
  }, rows.map((r, i) => /*#__PURE__*/React.createElement(Card, {
    key: r.title,
    variant: "outlined",
    padding: "0"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "auto 1fr auto",
      gap: 28,
      alignItems: "center",
      padding: "30px clamp(24px,3vw,40px)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 58,
      height: 58,
      borderRadius: 16,
      background: "var(--surface-brand-soft)",
      display: "grid",
      placeContent: "center",
      color: "var(--sr-tannengruen)"
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": r.icon,
    style: {
      width: 28,
      height: 28
    }
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 26,
      margin: "0 0 8px",
      color: "var(--text-strong)"
    }
  }, r.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 15,
      lineHeight: 1.5,
      color: "var(--text-muted)",
      margin: "0 0 14px",
      maxWidth: 560
    }
  }, r.body), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: 8
    }
  }, r.points.map(p => /*#__PURE__*/React.createElement(Badge, {
    key: p,
    tone: "brand"
  }, p)))), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    iconRight: /*#__PURE__*/React.createElement("i", {
      "data-lucide": "arrow-right",
      style: {
        width: 16,
        height: 16
      }
    })
  }, "Learn more"))))));
}
function Ecosystem() {
  const layers = [{
    k: "Dashboard",
    d: "Portfolio overview, energy analytics, alerts and schedules."
  }, {
    k: "Platform",
    d: "Optimization engine, rules and data model — the brain of the ecosystem."
  }, {
    k: "Gateways",
    d: "Edge devices bridging your building systems to the platform."
  }, {
    k: "Sensors & actuators",
    d: "Temperature, occupancy, metering and control points."
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--sr-dunkelgruen)",
      color: "#fff"
    }
  }, /*#__PURE__*/React.createElement("section", {
    style: {
      padding: "clamp(56px,7vw,96px) clamp(20px,5vw,64px)",
      maxWidth: 1000,
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      textTransform: "uppercase",
      letterSpacing: "0.22em",
      fontSize: 12,
      color: "var(--sr-neongruen)",
      marginBottom: 16
    }
  }, "All in one ecosystem"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "clamp(36px,5vw,64px)",
      lineHeight: 0.9,
      margin: "0 0 48px",
      maxWidth: 720
    }
  }, "Four layers, in symbiosis."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: 14
    }
  }, layers.map((l, i) => /*#__PURE__*/React.createElement("div", {
    key: l.k,
    style: {
      display: "grid",
      gridTemplateColumns: "48px 220px 1fr",
      gap: 22,
      alignItems: "center",
      padding: "22px 26px",
      background: "rgba(255,255,255,0.05)",
      border: "1px solid rgba(255,255,255,0.12)",
      borderRadius: "var(--radius-lg)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 22,
      color: "var(--sr-neongruen)"
    }
  }, String(i + 1).padStart(2, "0")), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 22
    }
  }, l.k), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 15,
      lineHeight: 1.5,
      color: "rgba(255,255,255,0.74)"
    }
  }, l.d))))));
}
function Contact() {
  const [sent, setSent] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface-page)"
    }
  }, /*#__PURE__*/React.createElement("section", {
    style: {
      padding: "clamp(56px,7vw,96px) clamp(20px,5vw,64px)",
      maxWidth: 1000,
      margin: "0 auto",
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 56,
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      textTransform: "uppercase",
      letterSpacing: "0.22em",
      fontSize: 12,
      color: "var(--text-brand)",
      marginBottom: 16
    }
  }, "Book a demo"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "clamp(34px,4.5vw,56px)",
      lineHeight: 0.9,
      margin: "0 0 20px",
      color: "var(--text-strong)"
    }
  }, "Let's upgrade your building."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 16,
      lineHeight: 1.55,
      color: "var(--text-muted)",
      maxWidth: 380
    }
  }, "Tell us about your portfolio and we'll show you the savings potential in a 30-minute walkthrough."), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 28,
      display: "grid",
      gap: 14
    }
  }, [["mail", "hello@smartrplace.de"], ["phone", "+49 30 000 000"], ["map-pin", "Berlin, Germany"]].map(([ic, tx]) => /*#__PURE__*/React.createElement("div", {
    key: tx,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      color: "var(--text-body)",
      fontFamily: "var(--font-sans)",
      fontSize: 15
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--sr-tannengruen)"
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": ic,
    style: {
      width: 18,
      height: 18
    }
  })), tx)))), /*#__PURE__*/React.createElement(Card, {
    variant: "elevated",
    padding: "30px"
  }, sent ? /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "center",
      padding: "40px 10px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 56,
      height: 56,
      borderRadius: "50%",
      background: "var(--surface-brand-soft)",
      display: "grid",
      placeContent: "center",
      margin: "0 auto 18px",
      color: "var(--sr-tannengruen)"
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "check",
    style: {
      width: 28,
      height: 28
    }
  })), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 24,
      margin: "0 0 8px",
      color: "var(--text-strong)"
    }
  }, "Thank you"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-sans)",
      color: "var(--text-muted)",
      margin: 0
    }
  }, "We'll be in touch within one business day.")) : /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "First name",
    placeholder: "Lena"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Last name",
    placeholder: "Vogt"
  })), /*#__PURE__*/React.createElement(Input, {
    label: "Work email",
    type: "email",
    placeholder: "lena@company.com",
    leadingIcon: /*#__PURE__*/React.createElement("i", {
      "data-lucide": "mail",
      style: {
        width: 18,
        height: 18
      }
    })
  }), /*#__PURE__*/React.createElement(Select, {
    label: "Portfolio size",
    options: ["1–5 buildings", "6–25 buildings", "26–100 buildings", "100+ buildings"]
  }), /*#__PURE__*/React.createElement(Textarea, {
    label: "What would you like to improve?",
    rows: 3,
    placeholder: "e.g. reduce heating cost across 12 sites"
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    fullWidth: true,
    onClick: () => setSent(true)
  }, "Book a demo")))));
}
Object.assign(window, {
  Solutions,
  Ecosystem,
  Contact
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Pages.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Divider = __ds_scope.Divider;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Metric = __ds_scope.Metric;

__ds_ns.ProgressBar = __ds_scope.ProgressBar;

__ds_ns.Alert = __ds_scope.Alert;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Textarea = __ds_scope.Textarea;

__ds_ns.Breadcrumb = __ds_scope.Breadcrumb;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
