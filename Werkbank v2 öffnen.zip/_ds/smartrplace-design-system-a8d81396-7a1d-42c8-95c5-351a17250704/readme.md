# Smartrplace Design System

A design system for **Smartrplace GmbH** — an "all in one ecosystem" for energy and space management that brings building hardware and software into symbiosis. Warm-green, understated, serious (*seriös und schlicht*), environment-centered.

> **Brand essence:** *Upgrade your Building. Space. Future.*
> Research-born innovation · Technology with purpose · All in one ecosystem.

---

## Sources

Everything here is derived from materials supplied by the client (stored in `uploads/`):

- **`Distinctive Smartrplace_Corporate-Identity.pdf`** — the primary CI document. Colors, typography specs (fonts, tracking, leading), background/pattern rules, button "Elemente" studies, and tone-of-voice were transcribed from it. Color values were extracted from the PDF's own fill operators (exact, not sampled).
- **`SMARTRPLACE_Signet_RGB-Positiv.png`** — the signet (abstract "S" of two rounded-stadium strokes). Primary green **#095441** was sampled directly from it.
- **`SMARTRPLACE_Wortbildmarke_RGB-Positiv+Claim.png`** — full word-image mark with claim.
- **`logo2026.1657d8ff.svg`** — vector wordmark (recolored to brand green; white + neon variants generated).
- **`ShipporiAntique-Regular.ttf`** — the display/headline gothic sans, self-hosted.

No codebase or Figma file was provided — UI kits are faithful brand-language recreations of the two obvious Smartrplace products (marketing site + operator dashboard), not reconstructions of shipped screens. See **CAVEATS** at the bottom.

---

## CONTENT FUNDAMENTALS — how Smartrplace writes

**Voice.** Confident and calm. The CI names six attributes: *Visionär, Dynamisch, Smart, Emotional, Seriös, Vielfältig*. In practice that reads as **serious and understated with a forward-looking edge** — never loud, never gimmicky.

**Person & address.** Speaks **to "you / your"** (the building owner / operator): *"Upgrade your Building."*, *"Smartrplace supports your daily space management."* The company refers to itself as *Smartrplace* or *we*, sparingly.

**The signature triad.** `Building. Space. Future.` — three short words, each a full stop. This staccato, period-separated rhythm is the brand's most recognizable copy device. Reuse it (e.g. hero headlines) but don't overuse it.

**Casing.**
- **Overlines** are UPPERCASE with wide tracking (e.g. `ALL IN ONE ECOSYSTEM`).
- **Headlines** are sentence case in the display gothic (Shippori Antique).
- **Body** is sentence case.
- Product concepts are lower/sentence case: *energy management, space management*.

**Tone examples (approved):**
- *"Upgrade your Building. Space. Future."*
- *"All in one ecosystem."*
- *"Environment-centered. Technology with purpose."*
- *"Smartrplace supports your daily space management."*
- *"Research-born innovation."*

**Language.** The company is German (Berlin); marketing claims are in **English**. German is fine for regional/product copy (the CI shows German body text). Keep sentences short and declarative.

**Emoji:** **none.** Not part of the brand. Do not introduce them.

**Numbers.** Energy results are concrete and honest (`−18%`, `1 204 kWh`, `€ 3 240`). Prefer the real figure over vague superlatives. Use a thin/space thousands separator in German style (`1 204`).

---

## VISUAL FOUNDATIONS

**Color.** Warm greens on warm paper.
- **Tannengrün `#095441`** — the anchor. Logo, primary buttons, hero backgrounds, brand cards.
- **Dunkelgrün `#03372A`** — deepest green; footers, section backgrounds, overlays.
- **Hellgrün `#409464`** — lighter sage; secondary data, comfort metrics.
- **Neongrün `#BDFF78`** — the one energetic accent. Highlights, a single CTA, data peaks, "screen" glow on deep green. **Use sparingly** — it loses meaning if everywhere.
- **Neutrals are green-leaning greys** (not cold), on a **warm off-white paper `#FBFBF8`**.
- Semantic: success `#2E8266`, warning `#C58A1E`, danger `#B23A32`, info `#2F6E8F`.

**Type.**
- **Display / Headlines / Overlines → Shippori Antique** (a clean gothic sans — same family feel as the wordmark). Tight leading (**0.85–0.92**). Headlines set large with near-1.0 line-height for a dense, confident block. Overlines UPPERCASE, very wide tracking (~0.24–0.28em).
- **Body / UI / Subline → Blinker** (sans; 400 + 600). Comfortable **1.3–1.5** leading, slight positive tracking.
- **Data / metrics → IBM Plex Mono.** All KPI numbers are mono for a technical, instrument feel.

**Backgrounds.** Two moods only: **warm paper** (light content) and **Tannengrün / Dunkelgrün** (brand moments). The signature texture is the **ascending signet pattern** — the mark repeated in a rising diagonal at ~10% opacity over green (per CI "Pattern auf Basis des Signets in aufsteigender Positionierung"). No stock gradients; the only gradient is a subtle Tannengrün→Dunkelgrün (`--brand-gradient`) for feature panels.

**Corner radii.** Generous and rounded, echoing the stadium-stroke signet. Controls and chips are **fully pill** (`--radius-pill`); cards use **18px** (`--radius-lg`); large panels **28px** (`--radius-xl`). Nothing is sharp-cornered.

**Cards.** White surface, **1px subtle border + soft green-tinted shadow** (`--shadow-md`). Variants: `elevated` (default), `outlined` (flat), `sunken`, and `brand` (Tannengrün fill, white text — the feature card).

**Shadows.** Low-contrast and **tinted with `#03372A`**, never neutral-black. Elevation ramps xs→xl stay soft. A dedicated **neon glow** (`--glow-neon`) is the only "screen-blend" effect, reserved for accent chips on dark.

**Borders / lines.** Hairline 1–1.5px in green-grey neutrals. Inputs use 1.5px, thickening to Tannengrün on focus with a soft focus ring (`--ring`).

**Motion.** Calm and purposeful — **no bounce**. Standard ease `cubic-bezier(0.2,0,0.1,1)`; durations 120/200/340ms. Fades and short slides only. Charts ease in. Respect `prefers-reduced-motion`.

**Hover / press.** Primary buttons **darken** on hover (Tannengrün → `--brand-hover`), neon buttons dim slightly (brightness 0.96), ghost/secondary get a **soft green tint** background. No scale-up. Press is a color shift, not a big shrink.

**Transparency & blur.** Sticky headers use `rgba(paper, 0.82)` + `blur(10px)`. Overlays are `rgba(3,35,27,0.42)` + light blur — always green-tinted, never grey.

**Imagery vibe.** Where photography is used it should read **warm, natural, daylight** — buildings, greenery, human-scale spaces. The signet and green washes stand in for imagery in this system.

**Layout.** Centered max-widths (1100–1320px), generous gutters (`--page-gutter`, clamp 20→80px). Left-aligned type blocks; big display headlines anchored top-left of sections.

---

## ICONOGRAPHY

- The brand ships **no icon font or icon set** of its own — the only proprietary glyph is the **signet** (`assets/logos/smartrplace-signet*.png`), used as a logo/pattern element, not as a UI icon.
- **Substitution (flagged):** for UI/product icons this system uses **Lucide** (`https://unpkg.com/lucide`), loaded from CDN. Lucide's **thin, rounded, single-weight stroke** matches the signet's rounded-stroke construction and the brand's calm, understated feel. If Smartrplace has a preferred icon library, swap the CDN link and the `data-lucide` names.
- Icons render at **18–24px**, in `--text-body` / `--text-muted`, or `--sr-tannengruen` inside tinted tiles. Never multicolor.
- **No emoji. No unicode-as-icon** (except the neutral `▾` select chevron and `✕` close affordance).
- In slides and static exports, keep icons as inline Lucide `<i data-lucide>` and call `lucide.createIcons()`.

---

## INDEX / manifest

**Root**
- `styles.css` — the single entry point consumers link. `@import`s all tokens + fonts.
- `readme.md` — this guide.
- `SKILL.md` — Agent-Skills-compatible wrapper.

**`tokens/`** — `fonts.css` (Shippori Antique self-host + Blinker/IBM Plex Mono via Google Fonts), `colors.css`, `typography.css`, `spacing.css`, `effects.css`.

**`assets/`**
- `fonts/ShipporiAntique-Regular.ttf`
- `logos/` — `smartrplace-wordmark.svg` (+ `-white`, `-neon`), `smartrplace-wortbildmarke.png`, `smartrplace-signet.png` (+ `-white`, `-neon`).

**`components/`** (React primitives, `window.SmartrplaceDesignSystem_a8d813`)
- `forms/` — **Button, IconButton, Input, Textarea, Select, Checkbox, Radio, Switch**
- `core/` — **Card, Badge, Tag, Avatar, Divider**
- `feedback/` — **Alert, Toast, Tooltip, Dialog**
- `navigation/` — **Tabs, Breadcrumb**
- `data/` — **Metric, ProgressBar**

**`guidelines/`** — foundation specimen cards (Colors, Type, Spacing, Brand) shown in the Design System tab.

**`ui_kits/`**
- `website/` — marketing site (Home, Solutions, Ecosystem, Contact).
- `dashboard/` — building-management dashboard (Overview, Building detail, Schedule).

**`slides/`** — sample branded slides (Title, Content, Stat, Section divider), 1280×720.

---

## CAVEATS
- **No codebase or Figma** was provided. The UI kits are original recreations that apply the brand language to Smartrplace's evident products — they are **not** reproductions of shipped screens. If real product UIs exist, share them (code or Figma) to make the kits faithful.
- **Icons are Lucide (substitution)** — see ICONOGRAPHY. Confirm or replace.
- **Blinker & IBM Plex Mono load from Google Fonts.** Only Shippori Antique was supplied. If you have licensed weights of Blinker (or a different mono), drop the `.ttf`/`.woff2` into `assets/fonts/` and add `@font-face` rules.
- CI color names map as: Tannengrün `#095441`, Dunkelgrün `#03372A`, Hellgrün `#409464`, Neongrün `#BDFF78`. "Hellgrün" was assigned to the medium secondary green found in the CI; confirm if a lighter tint was intended.
