/* allicaneat.food — Steuerungs-Dashboard: Inhalt + Rechenhilfen.
   Struktur/Inhalt getrennt: dieses File wird später 1:1 durch JSON ersetzt. */
window.AICE_DATA = {
  heute: "2026-08-28",
  prioritaeten: [
    { key: "dringend", label: "Dringend", rang: 1 },
    { key: "hoch",     label: "Hoch",     rang: 2 },
    { key: "normal",   label: "Normal",   rang: 3 },
    { key: "niedrig",  label: "Niedrig",  rang: 4 }
  ],
  restaurants: [
    {
      id: "allgemein", name: "Allgemein", allgemein: true,
      status: "Laufend", ort: "—",
      kontakt: null,
      notiz: "Aufgaben ohne Restaurantbezug — Pilotphase, Prozesse, Material.",
      dateien: [
        { name: "Pilotvertrag_Vorlage_v3.pdf", groesse: "218 KB", datum: "2026-08-19" },
        { name: "Onboarding_Checkliste.xlsx", groesse: "34 KB", datum: "2026-08-24" }
      ],
      aufgaben: [
        { id: "a1", titel: "Onboarding-Ablauf festlegen", prio: "dringend", faellig: "2026-08-31", person: "Beide", erledigt: false, notiz: "Reihenfolge: Vertrag → Speisekarte → Allergene → Testbestellung.", anhaenge: ["Onboarding_Checkliste.xlsx"] },
        { id: "a2", titel: "Pilotvertrag-Vorlage juristisch prüfen lassen", prio: "hoch", faellig: "2026-09-04", person: "Kollege", erledigt: false, notiz: "", anhaenge: ["Pilotvertrag_Vorlage_v3.pdf"] },
        { id: "a3", titel: "Feedback-Fragebogen für Woche 4 schreiben", prio: "normal", faellig: "2026-09-11", person: "Jan", erledigt: false, notiz: "", anhaenge: [] },
        { id: "a4", titel: "Preismodell nach Pilotphase skizzieren", prio: "niedrig", faellig: "2026-10-02", person: "Beide", erledigt: false, notiz: "Erst nach den ersten Zahlen aus dem Pilot.", anhaenge: [] },
        { id: "a5", titel: "Liste der Pilot-Restaurants abstimmen", prio: "hoch", faellig: "2026-08-21", person: "Beide", erledigt: true, notiz: "", anhaenge: [] }
      ]
    },
    {
      id: "vesuvio", name: "Trattoria Vesuvio", status: "Pilot startet",
      ort: "Wilhelmshöher Allee 112, Kassel",
      kontakt: { person: "Antonio Greco", rolle: "Inhaber", telefon: "0561 77 41 02", email: "greco@trattoria-vesuvio-ks.de" },
      notiz: "Sehr interessiert, will vor Unterschrift die Kündigungsfrist geklärt haben. Ruhig zwischen 15 und 17 Uhr.",
      dateien: [
        { name: "Pilotvertrag_Vesuvio.pdf", groesse: "204 KB", datum: "2026-08-26" },
        { name: "Speisekarte_Foto.jpg", groesse: "1,8 MB", datum: "2026-08-22" }
      ],
      aufgaben: [
        { id: "v1", titel: "Pilotvertrag zur Unterschrift schicken", prio: "dringend", faellig: "2026-09-02", person: "Jan", erledigt: false, notiz: "Kündigungsfrist auf 4 Wochen ändern, dann raus.", anhaenge: ["Pilotvertrag_Vesuvio.pdf"] },
        { id: "v2", titel: "Speisekarte digitalisieren", prio: "hoch", faellig: "2026-09-08", person: "Kollege", erledigt: false, notiz: "Fotos liegen vor, 42 Positionen.", anhaenge: ["Speisekarte_Foto.jpg"] },
        { id: "v3", titel: "Allergenliste vom Koch anfordern", prio: "dringend", faellig: "2026-08-25", person: "Jan", erledigt: false, notiz: "Zweimal nachgefragt, Koch war im Urlaub.", anhaenge: [] },
        { id: "v4", titel: "Erstgespräch führen", prio: "hoch", faellig: "2026-08-18", person: "Beide", erledigt: true, notiz: "", anhaenge: [] },
        { id: "v5", titel: "Öffnungszeiten und Ruhetag erfassen", prio: "normal", faellig: "2026-09-09", person: "Jan", erledigt: false, notiz: "", anhaenge: [] }
      ]
    },
    {
      id: "muehlgraben", name: "Café Mühlgraben", status: "Onboarding abgeschlossen",
      ort: "Mühlengasse 7, Kassel",
      kontakt: { person: "Sanna Reuter", rolle: "Geschäftsführerin", telefon: "0561 20 88 63", email: "hallo@cafe-muehlgraben.de" },
      notiz: "Referenzkunde. Hat den ganzen Ablauf in vier Tagen durchgezogen — als Vorbild für die anderen nutzen.",
      dateien: [
        { name: "Pilotvertrag_Muehlgraben_signiert.pdf", groesse: "312 KB", datum: "2026-08-20" },
        { name: "Speisekarte_final.csv", groesse: "12 KB", datum: "2026-08-21" },
        { name: "Allergenliste.pdf", groesse: "88 KB", datum: "2026-08-21" }
      ],
      aufgaben: [
        { id: "m1", titel: "Erstgespräch führen", prio: "hoch", faellig: "2026-08-12", person: "Beide", erledigt: true, notiz: "", anhaenge: [] },
        { id: "m2", titel: "Pilotvertrag zur Unterschrift schicken", prio: "dringend", faellig: "2026-08-17", person: "Jan", erledigt: true, notiz: "", anhaenge: ["Pilotvertrag_Muehlgraben_signiert.pdf"] },
        { id: "m3", titel: "Speisekarte digitalisieren", prio: "hoch", faellig: "2026-08-21", person: "Kollege", erledigt: true, notiz: "", anhaenge: ["Speisekarte_final.csv"] },
        { id: "m4", titel: "Allergenliste vom Koch anfordern", prio: "dringend", faellig: "2026-08-21", person: "Jan", erledigt: true, notiz: "", anhaenge: ["Allergenliste.pdf"] },
        { id: "m5", titel: "Testbestellung durchspielen", prio: "normal", faellig: "2026-08-24", person: "Beide", erledigt: true, notiz: "", anhaenge: [] }
      ]
    },
    {
      id: "karlsaue", name: "Bistro Karlsaue", status: "Wartet auf Rückmeldung",
      ort: "Auedamm 24, Kassel",
      kontakt: { person: "Mehmet Aydin", rolle: "Inhaber", telefon: "0561 31 55 19", email: "m.aydin@bistro-karlsaue.de" },
      notiz: "Antwortet nur per WhatsApp. Möchte erst nach dem Stadtfest starten (7. September).",
      dateien: [
        { name: "Gespraechsnotiz_18-08.txt", groesse: "3 KB", datum: "2026-08-18" }
      ],
      aufgaben: [
        { id: "k1", titel: "Allergenliste vom Koch anfordern", prio: "dringend", faellig: "2026-08-27", person: "Kollege", erledigt: false, notiz: "Koch ist erst ab Dienstag wieder da.", anhaenge: [] },
        { id: "k2", titel: "Pilotvertrag zur Unterschrift schicken", prio: "hoch", faellig: "2026-09-09", person: "Jan", erledigt: false, notiz: "Nach dem Stadtfest.", anhaenge: [] },
        { id: "k3", titel: "Erstgespräch führen", prio: "hoch", faellig: "2026-08-18", person: "Beide", erledigt: true, notiz: "", anhaenge: ["Gespraechsnotiz_18-08.txt"] },
        { id: "k4", titel: "Speisekarte digitalisieren", prio: "normal", faellig: "2026-09-15", person: "Kollege", erledigt: false, notiz: "", anhaenge: [] }
      ]
    },
    {
      id: "werk5", name: "Kantine Werk 5", status: "Pilot läuft",
      ort: "Lilienthalstraße 5, Kassel",
      kontakt: { person: "Doris Kleeberg", rolle: "Küchenleitung", telefon: "0561 94 12 70", email: "kleeberg@werk5-kantine.de" },
      notiz: "Große Küche, 480 Essen am Tag. Wechselnder Tagesplan — Speisekarte muss wöchentlich aktualisiert werden.",
      dateien: [
        { name: "Pilotvertrag_Werk5_signiert.pdf", groesse: "298 KB", datum: "2026-08-14" },
        { name: "Wochenplan_KW36.pdf", groesse: "62 KB", datum: "2026-08-26" }
      ],
      aufgaben: [
        { id: "w1", titel: "Wochenplan-Import einrichten", prio: "dringend", faellig: "2026-08-20", person: "Kollege", erledigt: false, notiz: "Blockiert die wöchentliche Aktualisierung. Doris wartet.", anhaenge: ["Wochenplan_KW36.pdf"] },
        { id: "w2", titel: "Allergenliste vom Koch anfordern", prio: "hoch", faellig: "2026-09-01", person: "Jan", erledigt: false, notiz: "", anhaenge: [] },
        { id: "w3", titel: "Erstgespräch führen", prio: "hoch", faellig: "2026-08-06", person: "Beide", erledigt: true, notiz: "", anhaenge: [] },
        { id: "w4", titel: "Pilotvertrag zur Unterschrift schicken", prio: "dringend", faellig: "2026-08-13", person: "Jan", erledigt: true, notiz: "", anhaenge: ["Pilotvertrag_Werk5_signiert.pdf"] },
        { id: "w5", titel: "Rückmeldung nach zwei Wochen einholen", prio: "normal", faellig: "2026-09-03", person: "Jan", erledigt: false, notiz: "", anhaenge: [] },
        { id: "w6", titel: "Kassensystem-Anbindung klären", prio: "niedrig", faellig: "2026-09-25", person: "Kollege", erledigt: false, notiz: "", anhaenge: [] }
      ]
    },
    {
      id: "fulda", name: "Osteria Fulda", status: "Pilot startet",
      ort: "Fuldabrücke 3, Kassel",
      kontakt: { person: "Chiara Bonetti", rolle: "Inhaberin", telefon: "0561 60 33 84", email: "bonetti@osteria-fulda.de" },
      notiz: "Will die Speisekarte selbst eintippen. Braucht dafür eine kurze Anleitung.",
      dateien: [
        { name: "Anleitung_Speisekarte.pdf", groesse: "410 KB", datum: "2026-08-25" }
      ],
      aufgaben: [
        { id: "f1", titel: "Pilotvertrag zur Unterschrift schicken", prio: "dringend", faellig: "2026-09-02", person: "Jan", erledigt: false, notiz: "", anhaenge: [] },
        { id: "f2", titel: "Anleitung Speisekarte-Eingabe verschicken", prio: "hoch", faellig: "2026-08-29", person: "Kollege", erledigt: false, notiz: "", anhaenge: ["Anleitung_Speisekarte.pdf"] },
        { id: "f3", titel: "Erstgespräch führen", prio: "hoch", faellig: "2026-08-20", person: "Beide", erledigt: true, notiz: "", anhaenge: [] },
        { id: "f4", titel: "Allergenliste vom Koch anfordern", prio: "normal", faellig: "2026-09-10", person: "Jan", erledigt: false, notiz: "", anhaenge: [] }
      ]
    },
    {
      id: "koenigsplatz", name: "Imbiss Königsplatz", status: "Wartet auf Rückmeldung",
      ort: "Königsplatz 41, Kassel",
      kontakt: { person: "Ergün Yildiz", rolle: "Inhaber", telefon: "0561 15 27 46", email: "imbiss.koenigsplatz@web.de" },
      notiz: "Kein Laptop im Laden, alles über Handy. Screenshots statt PDFs schicken.",
      dateien: [],
      aufgaben: [
        { id: "i1", titel: "Erstgespräch führen", prio: "hoch", faellig: "2026-08-26", person: "Kollege", erledigt: false, notiz: "Zweiter Versuch — beim ersten Termin war Hochbetrieb.", anhaenge: [] },
        { id: "i2", titel: "Pilotvertrag zur Unterschrift schicken", prio: "normal", faellig: "2026-09-05", person: "Jan", erledigt: false, notiz: "", anhaenge: [] },
        { id: "i3", titel: "Speisekarte digitalisieren", prio: "niedrig", faellig: "2026-09-18", person: "Kollege", erledigt: false, notiz: "Nur 14 Positionen.", anhaenge: [] }
      ]
    },
    {
      id: "sushinord", name: "Sushi Nord", status: "Neu angelegt",
      ort: "Holländische Straße 88, Kassel",
      kontakt: { person: "Kenji Sato", rolle: "Inhaber", telefon: "0561 88 04 21", email: "" },
      notiz: "Am Markttag angesprochen, Zusage mündlich. Aufgaben noch nicht angelegt.",
      dateien: [],
      aufgaben: []
    },
    {
      id: "davinci", name: "Da Vinci", status: "Pilot läuft",
      ort: "Friedrich-Ebert-Straße 152, Kassel",
      kontakt: { person: "Luisa Ferrante", rolle: "Betriebsleitung", telefon: "0561 45 99 30", email: "ferrante@davinci-kassel.de" },
      notiz: "Läuft ohne Probleme. Bittet um monatliche Auswertung per Mail.",
      dateien: [
        { name: "Pilotvertrag_DaVinci_signiert.pdf", groesse: "287 KB", datum: "2026-08-11" },
        { name: "Speisekarte_final.csv", groesse: "18 KB", datum: "2026-08-23" }
      ],
      aufgaben: [
        { id: "d1", titel: "Allergenliste vom Koch anfordern", prio: "hoch", faellig: "2026-09-04", person: "Jan", erledigt: false, notiz: "", anhaenge: [] },
        { id: "d2", titel: "Erstgespräch führen", prio: "hoch", faellig: "2026-08-05", person: "Beide", erledigt: true, notiz: "", anhaenge: [] },
        { id: "d3", titel: "Pilotvertrag zur Unterschrift schicken", prio: "dringend", faellig: "2026-08-10", person: "Jan", erledigt: true, notiz: "", anhaenge: ["Pilotvertrag_DaVinci_signiert.pdf"] },
        { id: "d4", titel: "Speisekarte digitalisieren", prio: "hoch", faellig: "2026-08-23", person: "Kollege", erledigt: true, notiz: "", anhaenge: ["Speisekarte_final.csv"] },
        { id: "d5", titel: "Monatsauswertung aufsetzen", prio: "normal", faellig: "2026-09-30", person: "Jan", erledigt: false, notiz: "", anhaenge: [] }
      ]
    }
  ]
};

window.AICE_UTIL = (function () {
  var WT = ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"];
  var PRIO = {
    dringend: { label: "Dringend", rang: 1, code: "D", marken: "!!!", punkte: 4 },
    hoch:     { label: "Hoch",     rang: 2, code: "H", marken: "!!",  punkte: 3 },
    normal:   { label: "Normal",   rang: 3, code: "N", marken: "!",   punkte: 2 },
    niedrig:  { label: "Niedrig",  rang: 4, code: "L", marken: "·",   punkte: 1 }
  };
  function tag(s) { var p = s.split("-"); return new Date(+p[0], +p[1] - 1, +p[2]); }
  function diff(a, b) { return Math.round((tag(b) - tag(a)) / 86400000); }
  function fmt(s) { var d = tag(s); return ("0" + d.getDate()).slice(-2) + "." + ("0" + (d.getMonth() + 1)).slice(-2) + "."; }
  function fmtLang(s) { var d = tag(s); return WT[d.getDay()] + " " + fmt(s) + tag(s).getFullYear().toString().slice(-2); }
  function relativ(heute, faellig) {
    var t = diff(heute, faellig);
    if (t < 0) return { tage: t, ueberfaellig: true, text: "überfällig seit " + Math.abs(t) + (Math.abs(t) === 1 ? " Tag" : " Tagen") , kurz: Math.abs(t) + "T über" };
    if (t === 0) return { tage: 0, ueberfaellig: false, text: "heute fällig", kurz: "heute" };
    if (t === 1) return { tage: 1, ueberfaellig: false, text: "morgen fällig", kurz: "morgen" };
    return { tage: t, ueberfaellig: false, text: "in " + t + " Tagen", kurz: "in " + t + " T" };
  }
  return { PRIO: PRIO, prio: function (k) { return PRIO[k] || PRIO.normal; }, diff: diff, fmt: fmt, fmtLang: fmtLang, relativ: relativ, tag: tag };
})();
